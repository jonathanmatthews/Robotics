For the correct format of files to run with the program please refer to:
simple.txt
dumbbell.txt
flail.txt
robot.txt