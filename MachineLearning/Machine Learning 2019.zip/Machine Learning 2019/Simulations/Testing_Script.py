import Seated_Stiff_Rod as Sim
import Plotting_Function as plot_me
import pygame
import pygame.event
from pygame.locals import *
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def last_max(times,angles): #finds the time of the last maximum of the swing
    for i in range(len(angles)):
        if np.abs(angles[len(angles)-i-1]) <= np.abs(angles[len(angles)-i-2]) and np.abs(angles[len(angles)-i-3]) <= np.abs(angles[len(angles)-i-2]):
            return times[len(angles)-i-2]

def last_min(times,angles): #finds the time the robot was at the minimum. It interpolates the data to make it more accurate.
    for i in range(len(angles)):
        if (angles[len(angles)-i-1] > 0 and angles[len(angles)-i-2] < 0) or (angles[len(angles)-i-1] < 0 and angles[len(angles)-i-2] > 0) :
            last_time = -angles[len(angles)-i-1]*((times[len(angles)-i-1]-times[len(angles)-i-2])/(angles[len(angles)-i-1]-angles[len(angles)-i-2]))+times[len(angles)-i-1]
            return last_time
            
#parameters that decide whether the simulation shows the display and if a force is applied
display = True
force = True

#choses the algorithm that is used on the simulation
alg = 'Starting' #starting is equivalent to the robotics team's startup script

if display:
    params = Sim.initialise_display(force)
else:
    params = Sim.initialise(force)


action = [0,0]
counter = 0
running = True

max_angle = 0

#offsets for calculating when to change position
offset_q = 0.1
offset_p = -0.1

angles = []
times = []
algs = []

while running:
    if alg == 'Starting':
        if (counter - 32) % 64 == 0 and counter > 32: #64 comes from resonant freq of 2.56Hz. 2.56/2 = 1.28 / 0.02(timestep) = 64
            if action == [1,1]: #switches between the 2 actions
                action = [0,0]
            elif action == [0,0]:
                action = [1,1]
        if counter == 32: #at the start, only a quarter period is required
            if action == [1,1]:
                action = [0,0]
            elif action == [0,0]:
                action = [1,1]
    
    elif alg == 'Quarter':
        max_time = last_max(times,angles)
        min_time = last_min(times,angles)
        
        if min_time > max_time: #if the last minimum time was greater the last maximum time, action is required soon
            quarter_period = np.abs(min_time-max_time) 
            switch_time = min_time+quarter_period+offset_q
            
        try: #in a try statement as switch time may be non (definitely a better way possible)
            if counter == round(switch_time/0.02):
                if action == [1,1]:
                    action = [0,0]
                elif action == [0,0]:
                    action = [1,1]
        except:
            pass
        
        
    elif alg == 'Parametric':
        max_time = last_max(times,angles)
        min_time = last_min(times,angles)
        
        if max_time > min_time:
            quarter_period = np.abs(max_time-min_time)
            switch_time_1 = max_time + quarter_period + offset_p
        elif min_time > max_time:
            quarter_period = np.abs(min_time-max_time)
            switch_time_2 = min_time + quarter_period + offset_p
        try:
            if counter == round(switch_time_1/0.02) or counter == round(switch_time_2/0.02): #2 switch times for the maximum and minimum switch times (avoids overwriting each other)
                if action == [1,0]:
                    action = [0,1]
                elif action == [0,1]:
                    action = [1,0]
        except:
            pass
      
        
    
    if display:
        for event in pygame.event.get(): #this stuff is needed so python doesn't crash when exit the program
            if event.type == QUIT:
                running = False
            elif event.type == KEYDOWN and event.key == K_ESCAPE:
                running = False

        output,params = Sim.stepper_display(*params,action)
    else:
        if counter == 54000: #time limit for non display version
            running = False
        output,params = Sim.stepper(*params,action)
    
    if counter % 500 == 0: #prints counter every 500 time steps to check progress
        print(counter)
    
    if alg == 'Starting':
        if counter >= 1457: #switches to the quarter period algorithm after a certain number of timesteps
            alg = 'Quarter'
    elif alg == 'Quarter':
        if np.abs(np.rad2deg(output[0])) > 10: #switches to parametric algorithm when the angle goes above 10 degrees
            alg = 'Parametric'
            action = [1,0]
            
    if np.abs(output[0]) > max_angle:
        max_angle = np.abs(output[0])
    
    times += [counter * 0.02] #saves all the data into separate lists so it can be plotted/used later
    angles += [np.rad2deg(output[0])]
    algs += [alg]
    counter += 1 #adds one to counter to keep track of the number of timesteps
    

pygame.display.quit() #code required to exit the pygame window so that it doesn't crash on exit
pygame.quit()



print(np.rad2deg(max_angle))

df = pd.DataFrame({'Time':times,'Angles':angles,'Alg':algs}) #saves the data into a csv file
df.to_csv('Sim data.csv',index=False, header=False)
#plot_me.plot() #plots the simulation data and robotics data
