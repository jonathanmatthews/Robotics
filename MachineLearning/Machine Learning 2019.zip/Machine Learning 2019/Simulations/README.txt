README
###################################################################################################################
Intro

The simulations were created using the pymunk physics engine so the dirty equations of motions didn't need to
be derived. This has meant that I had to learn how the package worked, this wasn't too bad but can be a bit 
confusing and can take time to get used to. If you have any further questions about any of it, just send me an 
email at BXH698@student.bham.ac.uk and I'll try my best to help.

###################################################################################################################
How to control the simulation

The simulation has been defined such that the simulation can be run with or without the display output. Usually
the machine learning algorithms will train on the non display version (initialise and stepper) and then you can
see if it's behaving as expected by looking at it on the display version (initialise_display and stepper_display).
The display is handled by the pygame package.

In the folder you should see each of the simulations named appropiately. In order to control the algorithms, you
must first initialise the environment, this defines the swing and robot so that it can then be used. This is done
by calling either the initialise or initialise_display functions in each file, passing it an argument of either
True or False. The argument decides whether a force will be applied at the very start of the simulation (i.e. is
the simulation self start or not). The function will then subsequently define all the parts of the simulation
needs then spits out a list containing all of them.

From then, the simulation can be stepped forward in time by calling the stepper or stepper_display function. This
function is passed the parameters list (this must be unpacked when used an argument i.e. stepper(*params,action)
that you received when calling the initialise function and also an action. The action is basically the action that
the robot will take and is comprised of a 2 item list [x,y]. Both x and y can take a value of either 0 or 1 with x
controlling the upper body and y controlling the lower leg. By passing it 0 or 1, the limbs will move in the 
appropiate directions. The function will then return 2 items, a list of outputs and the updated parameters. The 
list of outputs can be altered depending on what the machine learning algorithms work off but is currently angle 
and angular velocity of the main rod. The parameters is just the updated parameters of the system after it has been
simulated through the time step so this should just overwrite the existing parameters list you have.

In order to test the simulations, I have created the Testing_Script.py which you can use to see how the motion
of the swing looks. 

###################################################################################################################
Known issues

Currently spyder for some reason doesn't play well with pygame so occasionally you'll run the simulation with the
display and the kernel will crash. I haven't found a permanent fix for this anywhere but have a couple of
workarounds. If you run the simulation through the console, you never experience this error. This can be done
through spyder by changing the console by going to Run->Run configuration per file->Execute in an external system 
terminal. However by doing this you don't get any errors if the program crashes. In the future I would probably 
to using a package called pyglet to handle the display. If you look on the pymunk website, there should be more 
info on how you can implement this.

Currently the damping coefficient is a bit shit as it doesn't follow the correct form compared to the actual robot.
At the moment I'm using a workaround that is linearly dependant on the angular velocity of the swing. You should 
look to improve this next year as this is by far the biggest issue with the simulation itself 
(this website may help: http://farside.ph.utexas.edu/teaching/336k/Newtonhtml/node17.html#svelyd).

###################################################################################################################
Extras

I have also had a go at developing the robot swinging on a rope swing. It currently is not great but there's a
general concept there which can be used.