import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def plot():
    alg_limits = [0,0,0,0]
    
    df_robot = pd.read_csv("Actual data (no masses).csv",names=['Time','Event','Acc_x','Acc_y','Acc_z','Gyro_x','Gyro_y','Gyro_z','S_Enc_0','S_Enc 1','S_Enc_2','S_Enc_3','BE','Ang_vel','COM_x','COM_y','Alg','Pos'])
    df_sim = pd.read_csv("Sim data.csv",names=['Time','Angle','Algorithm'])
    
    for i in range(len(df_sim)):
        if df_sim.Algorithm.iloc[i] == 'Quarter':
            alg_limits[1] = df_sim.Time.iloc[i]
            break
    for i in range(len(df_sim)):
        if df_sim.Algorithm.iloc[i] == 'Parametric':
            alg_limits[2] = df_sim.Time.iloc[i]
            break
    
    alg_limits[3] = df_sim.Time.max()
    
    fig,ax = plt.subplots()
    #ax.plot(df_robot.Time,df_robot.BE-0.5,'r',label='Coding Team Data')
    ax.plot(df_sim.Time,df_sim.Angle,'b',label='Simulation Data')
    ax.set_xlabel('Time / s',fontsize=14)
    ax.set_ylabel('Angle / degrees',fontsize=14)
    ax.set_xlim(0,1080)
    colours = ['green','blue','red']
    algs = ['Starting','Quarter Period','Parametric']
    for i in range(3):
        ax.axvspan(alg_limits[i],alg_limits[i+1],facecolor=colours[i],alpha=0.2,label=algs[i])
    ax.legend()
    plt.show()