import sys
import pygame
from pygame.locals import *
import pymunk
import pymunk.pygame_util
import numpy as np
from pygame.color import *
import matplotlib.pyplot as plt


def add_swing(space):
    rotation_center_body = pymunk.Body(body_type = pymunk.Body.STATIC)
    rotation_center_body.position = (300,300)

    swing = pymunk.Body()
    swing.position = (300,121)
    rod = pymunk.Segment(swing, (0, 179), (0, 0), 2.0)
    rod.mass = 2.5
    seat = pymunk.Poly(swing, [(-20.0, 4), (20.0, 4), (20,-4),(-20,-4)])
    seat.mass = 1.065

    ceiling_joint = pymunk.PinJoint(swing, rotation_center_body, (0,179), (0,0))
    space.add(rod, seat, swing, ceiling_joint)
    
    return swing
    
def add_robot(space,swing):
    robot = []
    num_circles = 5
    circle_height = [15,95]
    circle_rad = (circle_height[1]-circle_height[0])/(2*(num_circles-1))
    
    
    for i in range(num_circles):
        robot.append(pymunk.Circle(swing, circle_rad, (0,circle_height[0]+(2*i*circle_rad))))
        robot[i].mass = 0
        space.add(robot[i])

    return robot

def main():
    num_circles = 5
    
    pygame.init()
    screen = pygame.display.set_mode((600, 600))
    pygame.display.set_caption("I'm so swungover")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Arial", 16)

    space = pymunk.Space()
    space.gravity = (0, -981)
    space.damping = 0.9
    
    swing = add_swing(space)
    robot = add_robot(space,swing)

    draw_options = pymunk.pygame_util.DrawOptions(screen)
    
    target_pos = 0
    robot_mass = 5
    swing_mom = [13798,18421]
    mom_step = (swing_mom[1]-swing_mom[0])/(num_circles-1)
    max_angle = 0
    running = True
    
    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.display.quit()
                pygame.quit()
                sys.exit(0)
            elif event.type == KEYDOWN and event.key == K_ESCAPE:
                pygame.display.quit()
                pygame.quit()
                sys.exit(0)
            elif event.type == KEYDOWN and event.key == K_UP:
                if target_pos < (num_circles-1):
                    target_pos += 1
            elif event.type == KEYDOWN and event.key == K_DOWN:
                if target_pos > 0:
                    target_pos -= 1
            elif event.type == KEYDOWN and event.key == K_SPACE:
                swing.apply_force_at_local_point((-20000,0),(0,0))
        
        for i in range(len(robot)):
            if i == target_pos:
                
                robot[i].color = THECOLORS["red"]
                robot[i].mass = robot_mass
            else:
                robot[i].color = THECOLORS["blue"]
                robot[i].mass = 0

        swing.moment = swing_mom[1] - (target_pos*mom_step)
        
        angle = np.rad2deg(np.arctan((swing.position[0]-300)/(swing.position[1]-300)))
        if swing.position[1] > 300:
            if swing.position[0] < 300:
                angle = 180 + angle
            elif swing.position[0] > 300:
                angle = -180 + angle
        if abs(angle) > max_angle:
            max_angle = abs(angle)
        
        screen.fill((255,255,255))
        space.debug_draw(draw_options)
            
        space.step(1/50.0)
        screen.blit(font.render("Angle = " + str(angle),1, THECOLORS["black"]), (0,0))
        screen.blit(font.render("Swing Velocity = " + str(swing.velocity),1, THECOLORS["black"]), (0,20))
        screen.blit(font.render("Mass of robot = " + str(swing.mass),1, THECOLORS["black"]), (0,40))
        screen.blit(font.render("Moment of inertia of robot = " + str(swing._get_moment),1, THECOLORS["black"]), (0,60))
        screen.blit(font.render("Target position = " + str(target_pos),1, THECOLORS["black"]), (0,80))
        screen.blit(font.render("Max Angle = " + str(round(max_angle,1)),1, THECOLORS["black"]), (0,100))
        pygame.display.flip()
        clock.tick(50)
        
        
    
    
    pygame.display.quit()
    pygame.quit()
    sys.exit(0)

if __name__ == '__main__':
    main()