import sys
import pygame
from pygame.locals import *
import pymunk
import pymunk.pygame_util
import numpy as np
from pymunk.vec2d import Vec2d
from pygame.color import *

def add_swing(space):
    no_links = 25
    
    rope_body = pymunk.Body()
    rope_body.position = (300,300)
    rope_shape = pymunk.Segment(rope_body,(0,0),(0,-179/no_links),2)
    rope_shape.mass = 4.0/no_links
    
    rotation_center_body = pymunk.Body(body_type = pymunk.Body.STATIC)
    rotation_center_body.position = (300,300)
    ceiling_pivot = pymunk.PivotJoint(rotation_center_body,rope_body,rotation_center_body.position)
    ceiling_pivot._set_collide_bodies(False)
    
    space.add(ceiling_pivot,rotation_center_body,rope_body,rope_shape)
    
    
    for i in range(1,no_links):
        rope_body_new = pymunk.Body()
        rope_body_new.position = (300,(300-i*(179/no_links)))
        rope_shape = pymunk.Segment(rope_body_new,(0,0),(0,-179/no_links),2)
        rope_shape.mass = 4.0/no_links
        rope_shape.filter = pymunk.ShapeFilter(categories=1)
        pivot = pymunk.PivotJoint(rope_body,rope_body_new,rope_body_new.position)
        pivot._set_collide_bodies(False)

        space.add(rope_body_new,rope_shape,pivot)
        rope_body = rope_body_new
        
        if np.abs(rope_body_new.position[1] - (111 + 28)) < (179/no_links):
            hand_piv = rope_body_new
            print(hand_piv.position)
            
    seat_body = pymunk.Body()
    seat_body.position = (300,111)
    l_supp = pymunk.Segment(seat_body,(-5,0),(0,10),2.0)
    r_supp = pymunk.Segment(seat_body,(5,0),(0,10),2.0)
    l_supp.mass = 0.01
    r_supp.mass = 0.01
    l_supp.filter = pymunk.ShapeFilter(categories=1)
    r_supp.filter = pymunk.ShapeFilter(categories=1)
    seat = pymunk.Poly(seat_body, [(-5, 2), (5, 2), (5,-2),(-5,-2)])
    seat.mass = 1.065
    seat.color = THECOLORS["pink"]
    seat.filter = pymunk.ShapeFilter(categories=1)
    seat_pivot = pymunk.PivotJoint(seat_body,rope_body_new,seat_body.position+(0,10))
    seat_pivot._set_collide_bodies(False)
    pivot_fric = pymunk.GearJoint(seat_body,rope_body_new,0,1)
    pivot_fric.max_force = 1e12
    
    space.add(seat_body,l_supp,r_supp,seat,seat_pivot)
    print(hand_piv.position)
    return seat_body,hand_piv

def add_robot(space,seat,rope_hand_segment):
    #define robot upper body and upper leg
    ubt = Vec2d(3.5,0)
    robot_u_points = [Vec2d(-4,31.64)+ubt,Vec2d(-4,0)+ubt,Vec2d(4,0)+ubt,Vec2d(4,31.64)+ubt]
        
    
    robot_body = pymunk.Body()
    robot_body.position = seat.position + (0,3)
    robot_u = pymunk.Poly(robot_body,robot_u_points)
    robot_u.mass = 3.311
    robot_u.color = THECOLORS["red"]
    robot_u.filter = pymunk.ShapeFilter(mask=pymunk.ShapeFilter.ALL_MASKS ^ 1)
    
    
    robot_u_leg = pymunk.Poly(seat,[(-0.5,3),(-10.5,3),(-10.5,8),(-0.5,8)])
    robot_u_leg.color = THECOLORS["red"]
    robot_u_leg.mass = 0.603
    
    #define robot lower leg
    robot_leg = pymunk.Body()
    robot_leg.position = seat.position
    robot_l_leg = pymunk.Poly(robot_leg,[(-10.5,5),(-10.5,-11.8),(-4.0,-11.8),(-4.0,5)])
    robot_l_leg.mass = 1.214
    robot_l_leg.color = THECOLORS["red"]
    space.add(robot_body,robot_u,robot_u_leg,robot_leg,robot_l_leg)
    
    arm_slider = pymunk.SlideJoint(robot_body,rope_hand_segment,(0,20),(0,0),0,15)
    space.add(arm_slider)
    
    #defines arms of robot
    #robot_u_arm = pymunk.Body()
    #robot_u_arm.position = robot_body.position + (0,25)
    #robot_u_arm_sh = pymunk.Poly(robot_u_arm,[(2,0),(2,-5),(-2,-5),(-2,0)])
    #robot_u_arm_sh.mass = 0.1
    #robot_u_arm_sh.color = THECOLORS["purple"]
    #robot_u_arm_sh.filter = pymunk.ShapeFilter(categories=1)
    
    #robot_l_arm = pymunk.Body()
    #robot_l_arm.position = robot_body.position + (0,20)
    #robot_l_arm_sh = pymunk.Poly(robot_l_arm,[(2,0),(2,5),(-2,5),(-2,0)])
    #robot_l_arm_sh.mass = 0.1
    #robot_l_arm_sh.color = THECOLORS["green"]
    #robot_l_arm_sh.filter = pymunk.ShapeFilter(categories=1)
    
    #space.add(robot_u_arm,robot_u_arm_sh,robot_l_arm,robot_l_arm_sh)
    
    #pivots for shoulder, elbow and hands
    #shoulder_piv = pymunk.PivotJoint(robot_body,robot_u_arm,robot_u_arm.position)
    #shoulder_piv._set_collide_bodies(False)
    
    #elbow_piv = pymunk.PivotJoint(robot_u_arm,robot_l_arm,robot_l_arm.position)
    #elbow_piv._set_collide_bodies(False)
    
    #hand_piv = pymunk.PivotJoint(robot_l_arm,rope_hand_segment, rope_hand_segment.position)
    #hand_piv._set_collide_bodies(False)
    
    #space.add(shoulder_piv,elbow_piv,hand_piv)
    
    #motor and pivot for hip
    #uses measured values of angles rather than given in program
    seat_motor = pymunk.SimpleMotor(seat,robot_body,0)
    seat_motor.max_force = 1e7
    seat_pivot = pymunk.PivotJoint(seat,robot_body,robot_body.position+ubt)
    seat_pivot._set_collide_bodies(False)
    seat_pivot_lim = pymunk.RotaryLimitJoint(robot_body,seat,0,0.575959)
    space.add(seat_motor,seat_pivot,seat_pivot_lim)
    
    #motor and pivot for knee
    max_knee_ang = 0.26
    knee_motor = pymunk.SimpleMotor(seat,robot_leg,0)
    knee_motor.max_force = 1e5
    knee_pivot = pymunk.PivotJoint(seat,robot_leg,seat.position+(-8,7))
    knee_pivot._set_collide_bodies(False)
    knee_pivot_lim = pymunk.RotaryLimitJoint(seat,robot_leg,max_knee_ang-np.deg2rad(69),max_knee_ang)
    space.add(knee_motor,knee_pivot,knee_pivot_lim)

    return seat_motor,knee_motor,robot_body

def main():    
    pygame.init()
    screen = pygame.display.set_mode((600, 600))
    pygame.display.set_caption("The robot get's loads of girls. He's a bit of a swinger")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Arial", 16)

    space = pymunk.Space()
    space.gravity = (0, -981)
    space.damping = 0.8
    
    swing,hand_piv = add_swing(space)
    
    seat_motor,knee_motor,robot_u = add_robot(space,swing,hand_piv)
    draw_options = pymunk.pygame_util.DrawOptions(screen)
    
    
    
    running = True
    
    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.display.quit()
                pygame.quit()
                sys.exit(0)
            elif event.type == KEYDOWN and event.key == K_ESCAPE:
                pygame.display.quit()
                pygame.quit()
                sys.exit(0)
            elif event.type == KEYDOWN and event.key == K_RIGHT:
                seat_motor.rate = 3
                knee_motor.rate = 6
            elif event.type == KEYDOWN and event.key == K_LEFT:
                seat_motor.rate = -3
                knee_motor.rate = -6
            elif event.type == KEYDOWN and event.key == K_DOWN:
                seat_motor.rate = 0
                knee_motor.rate = 0
            elif event.type == KEYDOWN and event.key == K_SPACE:
                swing.apply_force_at_world_point((-500000,0),(0,0))
                

        
        screen.fill((255,255,255))
        space.debug_draw(draw_options)
        for _ in range(10):
            space.step(1/500.0)
        pygame.display.flip()
        clock.tick(50)
    
if __name__ == '__main__':
    main()